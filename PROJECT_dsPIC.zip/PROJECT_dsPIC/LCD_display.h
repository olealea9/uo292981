void LCD_Display_Setup(void);
void LCD_Display_ClrCol(unsigned char x);
void LCD_Display_Pixel(unsigned char x,unsigned char y);
void LCD_Display_Byte(unsigned char value);
void LCD_Display_array(int *array_ptr[]);
