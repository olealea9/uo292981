#include "Main.h"
#include "Func.h"
#include "dsp.h"
#include "math.h"

/* Este archivo contendr� la definici�n de las funciones auxiliares que se
 * necesiten para la ejecuci�n del c�digo.
 * Pueden a�adirse tantas como se quiera.
 * El objetivo es encapsular lo m�ximo posible el c�digo y reutilizar todas las+
 * funciones posibles.
 * En el archivo FUNC.H deber�n incluirse los prototipos de estas funciones.
 */

// Ejemplo:
// FUNCI�N PARA INICIALIZACI�N DE PUERTOS E/S
// Par�metros de entrada: ninguno (void).
// Par�metros de salida: ninguno (void).
void InitIO()
{
    LATD = 0xFFFF;                //Turn off all LEDS
    TRISD = 0xFFF0;               //Set LED pins as outputs
    TRISB = 0xFFFF;               //Set pushbutton switch pins as inputs
    
    TRISBbits.TRISB10 = 1;  //input triangular signal
    TRISBbits.TRISB11 = 1;  //input sinusoidal signal  
    TRISDbits.TRISD0 = 0;  //pwm
        
    return;
}// InitIO

void InitTMR1 ()
{
    T1CON = 0;
    TMR1 = 0;
    PR1 = (FCY/256)/2;
    T1CON = 0x0030;
    
    return;
}

void InitTMR3 ()
{
    T3CON = 0;
    TMR3 = 0;
    PR3 = (FCY/256)/2000;
    T3CON = 0x0030;
    
    return;
}


void InitLCD()
{
LCD_Display_Setup(); // INICIALIZA LCD
LCD_Display_Byte(HOME_CLEAR); // BORRA LCD
LCD_Display_Byte(CURSOR_ON); // PONE CURSOR
return;
}


void InitADC()
{   
    // ADCON1 CONFIGURATION
    ADCON1bits.ADON = 0;        // Initially, stopped.
    ADCON1bits.ADSIDL = 0;      // No IDLE
    ADCON1bits.FORM = 0b00;     // Output format = unsigned integer
    ADCON1bits.SSRC = 0b010;    // Source for triggering conversion = auto (111) con 010 disparo con TMR3
    ADCON1bits.ASAM = 1;        // Sampling after conversion ends

    // ADCON2 CONFIGURATION
    ADCON2bits.VCFG = 0b000;    // Vref+ = VDD, Vref- = VSS.
    ADCON2bits.SMPI = 0b1011;   // Interrupts after 15 conversion
    ADCON2bits.BUFM = 0;        // 16 words
    ADCON2bits.CSCNA = 1;
    ADCON2bits.ALTS = 0;
    ADCON2bits.BUFS = 0;
           
    // ADCON3 CONFIGURATION
    ADCON3bits.SAMC = 0b01111;   // 15�Tad 
    ADCON3bits.ADCS = 4;        // Clock Tad
    ADCON3bits.ADRC = 0;        // internal clock
    
    // ADCPCFG
    ADPCFG = 0xFFFF;

	
    ADPCFGbits.PCFG10 = 0;
    ADPCFGbits.PCFG11 = 0;

    
    // ADCSSL
    ADCSSL = 0x0000;

    ADCSSLbits.CSSL11 = 1;  
    ADCSSLbits.CSSL10 = 1;
    
    ADCON1bits.ADON = 1;        // turn ADC ON
    
    
    return;
}

void ConfigInt()
{
    // Configuring the interrupts
    INTCON1bits.NSTDIS = 1;         // Disable nesting interrputs 
    
    //CAD
    IFS0bits.ADIF = 0;     //clear adc flag          
    IEC0bits.ADIE = 1;     //enable adc mask        
    IPC2bits.ADIP = 5;     //adc priority level
 
    //TMR1
    IFS0bits.T1IF = 0;              
    IEC0bits.T1IE = 1;              
    IPC0bits.T1IP = 4;              
    
    //SW1
    IFS1bits.INT1IF = 0;              
    IEC1bits.INT1IE = 1;              
    IPC4bits.INT1IP = 4;  
    
    //SW2
//    IFS1bits.INT2IF = 0;              
//    IEC1bits.INT2IE = 1;              
//    IPC5bits.INT2IP = 2;  
    

    
    SET_CPU_IPL(1);                 // Set CPU priority level to a value below the lowest interrupt
    return;   
}


float Avg(float array[], unsigned int size)
{
    float suma = 0;
    unsigned int i = 1;
    for(i=0; i<size; i++)
        suma = suma + array[i];
    return suma/(size);
}

float Max(float array[], unsigned int size)
{
    float max = 0;
    unsigned int i = 0;
    for(i=0; i<size; i++)
    {
        if (max<array[i])
            max = array[i];
    }
    return max;
}


float rms (float array[], unsigned int size)
{
    float suma;
    float value_rms;
    unsigned int i = 0;
    for (i=0; i<size; i++)
    {
         suma = suma+ array[i];
    }
    value_rms=sqrt((1/1.0*size))*suma;
    return value_rms;
}


void GenPwm(float duty)
{
    if (duty > 1){
        duty = 0.9; //max
    }
    if (duty < 0){
        duty = 0.1; //min
    } 
    
    PR2 = FCY/737;
    T2CON = 0x0000;
    
    OC1CONbits.OCTSEL = 0;
    OC1CONbits.OCM = 0b110;
    OC1CONbits.OCSIDL =0;
    
    OC1RS = duty*PR2;
    return;
}


void Print_Tension(float max_tr, float max_sen, float min_tr, float min_sen, float rms_tr, float rms_sen)
{
    unsigned int tamano = 30;
    char fila1[tamano];
    char fila2[tamano];
    char fila3[tamano];
    char fila4[tamano];

    sprintf(fila1, "10:M=%.2fV;m=%.2fV\n",max_tr,min_tr);
    sprintf(fila2, "10:rms=%.2fV\n",rms_tr);
    sprintf(fila3, "11:M=%.2fV;m=%.2fV\n",max_sen,min_sen);
    sprintf(fila4, "11:rms=%.2fV",rms_sen);
 
    unsigned int TxIndex1 = 0;
    unsigned int TxIndex2 = 0;
    unsigned int TxIndex3 = 0;
    unsigned int TxIndex4 = 0;   
   
    while(fila1[TxIndex1])
    {
        LCD_Display_Byte(WRITE_CHAR);
        LCD_Display_Byte(fila1[TxIndex1++]);
    }
    
    while(fila2[TxIndex2])
    {
        LCD_Display_Byte(WRITE_CHAR);
        LCD_Display_Byte(fila2[TxIndex2++]);
    }
    
    while(fila3[TxIndex3])
    {
        LCD_Display_Byte(WRITE_CHAR);
        LCD_Display_Byte(fila3[TxIndex3++]);
    }
      
    while(fila4[TxIndex4])
    {
        LCD_Display_Byte(WRITE_CHAR);
        LCD_Display_Byte(fila4[TxIndex4++]);
    }
}







