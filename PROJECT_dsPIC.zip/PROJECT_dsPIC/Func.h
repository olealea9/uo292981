/* 
 * File:   Func.h
 * Author: AVA
 *
 */

/* En este archivo deben incluirse los prototipos de las funciones utilizadas en
 * FUNC.C.
 */

#ifndef FUNC_H
#define	FUNC_H

// EJEMPLO:
void InitIO(void);
void InitLCD(void);
void InitADC();
void ConfigInt();
void GemPwm(float);

float Avg(float*, unsigned int);
float Max(float*, unsigned int);
float rms(float*, unsigned int);

void InitTMR1();
void InitTMR3();
void Print_Tension(float, float, float, float, float, float);


// A�adir tantos prototipos como sea necesario.

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* FUNC_H */

