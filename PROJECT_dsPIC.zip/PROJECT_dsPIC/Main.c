/*
 * File:   Main.c
 * Author: SEA - Aitor VA
 * D.E.P. - GiTELE - 2019-2020
 */

/* 
 * File:   Main.c
 * Author: AVA

 */

/* Este proyecto tiene como objetivo proveer los archivos base y la estructura
 * T�pica de programaci�n para usar durante la asignatura. L�ease con atenci�n
 * las recomendaciones y las instrucciones de uso.
 */

// SIEMPRE SE INCLUIR�N ESTOS ARCHIVOS DE CABECERA:
#include "Config.h"
#include "Main.h"
#include "Func.h"
#include "LCD_display.h"
#include "dsp.h"
#include "math.h"

#define NUM_SAMPLES 256


//---------------------------------------------------------------------------
// Global variables

float duty = 0.5;

float rms_tr;
float rms_sen;
float max_tr;
float max_sen;
float min_tr;
float min_sen;

unsigned int posicion;

float array_tr[NUM_SAMPLES];
float array_sen[NUM_SAMPLES];



//---------------------------------------------------------------------------
// En este espacio pueden declararse las variables globales o las constantes.
// Ejemplo:
// unsigned int MiValor = 0;



/* Variables externas generadas con la toolbox FilterDesigner de MatLab */

extern FIRStruct filterbandpassFilter;
fractional array_triangular[NUM_SAMPLES];
fractional array_senoidal[NUM_SAMPLES];
fractional filtradaTR[NUM_SAMPLES];
fractional filtradaSEN[NUM_SAMPLES];


//---------------------------------------------------------------------------
// ISR routine
//---------------------------------------------------------------------------

// Llamada a la subrutina de interrupci�n. Descomentar estas l�neas para activarla.
// Debe incluirse el nombre de la rutina de interrupci�n (vector de interrupci�n).
// Esta llamada a la funci�n de interrupci�n debe repetirse tantas veces como
// vectores de interrupci�n haya (cada una, con su vector correspondiente)

void __attribute__((interrupt, auto_psv)) _ADCInterrupt(void)
{
	IFS0bits.ADIF = 0;          // Clean flag
    
    unsigned int tr = ADCBUFA; //12 bits the number that (ads gets a number between 0 and 4096)
    unsigned int sen = ADCBUFB; 
    array_tr[posicion]=1.0*tr*(5.0/4096.0); //converting info from buffer to volts. 
    array_sen[posicion]=1.0*sen*(5.0/4096.0); 
    array_triangular[posicion]=array_tr[posicion]*0x8000;
    array_senoidal[posicion]=array_sen[posicion]*0x8000; 
    posicion++;  
    while(posicion < NUM_SAMPLES)
    {
        FIR(NUM_SAMPLES, &filtradaTR, &array_triangular, &filterbandpassFilter);
        FIR(NUM_SAMPLES, &filtradaSEN, &array_senoidal, &filterbandpassFilter);
    }   
    if (posicion>NUM_SAMPLES){
        posicion=0;
    }
    ADCON1bits.ADON = 1; //turn adc on
}


void __attribute__((interrupt, auto_psv)) _T1Interrupt(void)
{
	IFS0bits.T1IF = 0;  
    T1CONbits.TON = 0;
    TMR1 = 0; 
    
    InitLCD(); //initialize LCD
    
    //triangular and senoidal signals
    
     rms_tr = rms(array_tr, NUM_SAMPLES);
     rms_sen = rms(array_sen, NUM_SAMPLES);
     max_tr = Max(array_tr, NUM_SAMPLES);
     max_sen = Max(array_sen, NUM_SAMPLES);
     min_tr = Avg(array_tr, NUM_SAMPLES);
     min_sen = Avg(array_sen, NUM_SAMPLES);
     
    Print_Tension(max_tr, max_sen, min_tr, min_sen, rms_tr, rms_sen);
    
    //print all the values
    
    T1CONbits.TON = 1;
   
}

void __attribute__((interrupt, auto_psv)) _INT1Interrupt(void)
{
    IFS1bits.INT1IF = 0;
    
    duty = duty + 0.1; //increment duty
    
    if (duty > 1)
    {
       duty = 0.5; 
    }
    
    GenPwm(duty);
}

void __attribute__((interrupt, auto_psv)) _INT2Interrupt(void)
{
    IFS1bits.INT2IF = 0;
    
    duty = duty - 0.1; //decrement duty
    
    if (duty < 0.1)
    {
       duty = 0.5; 
    }
    
    GenPwm(duty);
}


//---------------------------------------------------------------------------
// Main routine
//---------------------------------------------------------------------------

// Funci�n principal. Siempre incluye un bucle infinito.

int main (void)
{   
    // Aqu� se declarar�an las variables LOCALES a la funci�n Main.
    
    InitIO();                    // Initialize I/O ports
  //  InitLCD();
    InitTMR1();
    InitADC();
    InitTMR3();
    ConfigInt();
    GenPwm(duty);
    
  //  FIRDelayInit(&filterbandpassFilter);
    
    T1CONbits.TON = 1;
    T2CONbits.TON = 1;
    T3CONbits.TON = 1;

     
    while (1)   // bucle infinito
    {
   
    }
    
    return 0;
    
}// Main
