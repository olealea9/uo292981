/* 
 * File:   func.c
 * Author: Olga
 *
 * Created on May 30, 2022, 10:37 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include "func.h"


//float Avg(unsigned int array[], unsigned int size){
//    
//    float suma;
//    unsigned int i = 0;
//    for(i=0;i<size;i++)
//        suma = suma + array[i];
//    
//    return suma/(size);
//}
//
//unsigned int Max(unsigned int array[], unsigned int size){
//    
//    unsigned int max=0;
//    unsigned int i = 0;
//    for(i=0;i<size;i++)
//    {
//        if(max<array[i])
//            max = array[i];
//    }
//    
//    return max;
//    }
//
//unsigned int Min(unsigned int array[], unsigned int size){
//    
//    unsigned int min = 65535;
//    unsigned int i = 0;
//    for(i = 0; i<size; i++)
//    {
//        if(min>array[i])
//            min = array[i];
//        
//                    
//    }
//    
//    return min;
//}