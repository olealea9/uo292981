/* 
 * File:   func.c
 * Author: Olga
 *
 * Created on May 30, 2022, 10:37 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include "func.h"

void Efecto1(unsigned int aux){
    switch(aux){
       case 0:LATEbits.LATE0 = 1;
       break;
       
       case 1:
           LATEbits.LATE1 = 1;
           LATEbits.LATE0 = 0;
       break;
       
       case 2:
           LATBbits.LATB14 = 1;
           LATEbits.LATE0 = 0;
           LATEbits.LATE1 = 0;
       break;
       case 3:
           LATDbits.LATD7 = 1;
           LATEbits.LATE0 = 0;
           LATEbits.LATE1 = 0;
           LATBbits.LATB14 = 0;
	 break;
       case 4:
           
           LATDbits.LATD5 = 1;
           LATEbits.LATE0 = 0;
           LATEbits.LATE1 = 0;
           LATDbits.LATD7 = 0;
           LATBbits.LATB14 = 0;
       
	 break;
     
      default:
          
         LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
    }
    return;
}


void Efecto2(unsigned int aux){
    switch(aux){   //prove that in each case more than one order can be placed
       case 0:
	       LATEbits.LATE0 = 1;
	 break;
       
       case 1:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
	 break;

	 case 2:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
	 break;

       case 3:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=1;
       break;

       case 4:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=1;
		 LATDbits.LATD5=1;
       break;

       case 5:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=1;
		 LATDbits.LATD5=0;
       break;

       case 6:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
       break;

       case 7:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14 = 0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
	 break;

       case 8:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
       break;

	 case 9:
		 LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
       break;
       

	 default:
		 LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
    }
    return;
}   


void ConfigInt(){
    // Configuring the interrupts
    INTCON1bits.NSTDIS = 1;         // Disable nesting interrputs 
    
    
    
    IEC0bits.T1IE = 1;
    IFS0bits.T1IF = 0;
    IPC0bits.T1IP = 3;

        
    SET_CPU_IPL(1);                 // Set CPU priority level to a value below the lowest interrupt
    
    return;   
}
